﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Studiofinal
{
    public partial class customer_Login : Form
    {
        string username ;
        string password;
        public customer_Login()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(username) ||
      string.IsNullOrEmpty(password))
            {
                MessageBox.Show("Please fill all the information", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                MessageBox.Show(" SUCCEFULLY LOGIN AS CUSTOMER");
                Hide();
                orderpage orderpageform = new orderpage();
                orderpageform.Show();
            }
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            password = textBox2.Text;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            username = textBox1.Text;
        }

        private void back_Click(object sender, EventArgs e)
        {
            merchantorcustomer newform = new merchantorcustomer();
            Hide();          
            newform.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
        }
    }
}
