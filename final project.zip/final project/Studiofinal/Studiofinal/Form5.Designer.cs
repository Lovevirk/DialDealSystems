﻿namespace Studiofinal
{
    partial class customer_Signup
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.fbox = new System.Windows.Forms.TextBox();
            this.lbox = new System.Windows.Forms.TextBox();
            this.gender = new System.Windows.Forms.GroupBox();
            this.gButton3 = new System.Windows.Forms.RadioButton();
            this.gButton2 = new System.Windows.Forms.RadioButton();
            this.gButton1 = new System.Windows.Forms.RadioButton();
            this.ebox = new System.Windows.Forms.TextBox();
            this.nbox = new System.Windows.Forms.TextBox();
            this.ubox = new System.Windows.Forms.TextBox();
            this.pbox = new System.Windows.Forms.TextBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.button2 = new System.Windows.Forms.Button();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvider2 = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvider3 = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvider4 = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvider5 = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvider6 = new System.Windows.Forms.ErrorProvider(this.components);
            this.back = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.gender.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider6)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(507, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(116, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "First Name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(783, 20);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(115, 25);
            this.label2.TabIndex = 1;
            this.label2.Text = "Last Name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(792, 96);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(71, 25);
            this.label3.TabIndex = 2;
            this.label3.Text = "e-mail";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(783, 176);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(150, 25);
            this.label4.TabIndex = 3;
            this.label4.Text = "phone number";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(783, 252);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(107, 25);
            this.label5.TabIndex = 4;
            this.label5.Text = "username";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(783, 319);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(104, 25);
            this.label6.TabIndex = 5;
            this.label6.Text = "password";
            // 
            // fbox
            // 
            this.fbox.Location = new System.Drawing.Point(512, 48);
            this.fbox.Name = "fbox";
            this.fbox.Size = new System.Drawing.Size(161, 22);
            this.fbox.TabIndex = 1;
            this.fbox.Leave += new System.EventHandler(this.fbox_Leave);
            // 
            // lbox
            // 
            this.lbox.Location = new System.Drawing.Point(788, 48);
            this.lbox.Name = "lbox";
            this.lbox.Size = new System.Drawing.Size(158, 22);
            this.lbox.TabIndex = 2;
            this.lbox.Leave += new System.EventHandler(this.lbox_Leave);
            // 
            // gender
            // 
            this.gender.BackColor = System.Drawing.Color.Transparent;
            this.gender.Controls.Add(this.gButton3);
            this.gender.Controls.Add(this.gButton2);
            this.gender.Controls.Add(this.gButton1);
            this.gender.ForeColor = System.Drawing.Color.White;
            this.gender.Location = new System.Drawing.Point(512, 111);
            this.gender.Name = "gender";
            this.gender.Size = new System.Drawing.Size(181, 100);
            this.gender.TabIndex = 3;
            this.gender.TabStop = false;
            this.gender.Text = "gender";
            this.gender.Enter += new System.EventHandler(this.gender_Enter);
            // 
            // gButton3
            // 
            this.gButton3.AutoSize = true;
            this.gButton3.Location = new System.Drawing.Point(7, 74);
            this.gButton3.Name = "gButton3";
            this.gButton3.Size = new System.Drawing.Size(58, 20);
            this.gButton3.TabIndex = 2;
            this.gButton3.TabStop = true;
            this.gButton3.Text = "other";
            this.gButton3.UseVisualStyleBackColor = true;
            this.gButton3.CheckedChanged += new System.EventHandler(this.gButton3_CheckedChanged);
            // 
            // gButton2
            // 
            this.gButton2.AutoSize = true;
            this.gButton2.Location = new System.Drawing.Point(7, 49);
            this.gButton2.Name = "gButton2";
            this.gButton2.Size = new System.Drawing.Size(69, 20);
            this.gButton2.TabIndex = 3;
            this.gButton2.TabStop = true;
            this.gButton2.Text = "female";
            this.gButton2.UseVisualStyleBackColor = true;
            this.gButton2.CheckedChanged += new System.EventHandler(this.gButton2_CheckedChanged);
            // 
            // gButton1
            // 
            this.gButton1.AutoSize = true;
            this.gButton1.Location = new System.Drawing.Point(7, 22);
            this.gButton1.Name = "gButton1";
            this.gButton1.Size = new System.Drawing.Size(58, 20);
            this.gButton1.TabIndex = 3;
            this.gButton1.TabStop = true;
            this.gButton1.Text = "male";
            this.gButton1.UseVisualStyleBackColor = true;
            this.gButton1.CheckedChanged += new System.EventHandler(this.gButton1_CheckedChanged);
            // 
            // ebox
            // 
            this.ebox.Location = new System.Drawing.Point(788, 124);
            this.ebox.Name = "ebox";
            this.ebox.Size = new System.Drawing.Size(158, 22);
            this.ebox.TabIndex = 4;
            this.ebox.Leave += new System.EventHandler(this.ebox_Leave);
            // 
            // nbox
            // 
            this.nbox.Location = new System.Drawing.Point(788, 204);
            this.nbox.Name = "nbox";
            this.nbox.Size = new System.Drawing.Size(158, 22);
            this.nbox.TabIndex = 5;
            this.nbox.Leave += new System.EventHandler(this.nbox_Leave);
            // 
            // ubox
            // 
            this.ubox.Location = new System.Drawing.Point(788, 280);
            this.ubox.Name = "ubox";
            this.ubox.Size = new System.Drawing.Size(158, 22);
            this.ubox.TabIndex = 11;
            this.ubox.Leave += new System.EventHandler(this.ubox_Leave);
            // 
            // pbox
            // 
            this.pbox.Location = new System.Drawing.Point(788, 351);
            this.pbox.Name = "pbox";
            this.pbox.Size = new System.Drawing.Size(158, 22);
            this.pbox.TabIndex = 6;
            this.pbox.Leave += new System.EventHandler(this.pbox_Leave);
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(884, 379);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(69, 20);
            this.checkBox1.TabIndex = 8;
            this.checkBox1.Text = "unhide";
            this.checkBox1.UseVisualStyleBackColor = true;
            this.checkBox1.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(788, 379);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 15;
            this.button2.Text = "reset";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // errorProvider2
            // 
            this.errorProvider2.ContainerControl = this;
            // 
            // errorProvider3
            // 
            this.errorProvider3.ContainerControl = this;
            // 
            // errorProvider4
            // 
            this.errorProvider4.ContainerControl = this;
            // 
            // errorProvider5
            // 
            this.errorProvider5.ContainerControl = this;
            // 
            // errorProvider6
            // 
            this.errorProvider6.ContainerControl = this;
            // 
            // back
            // 
            this.back.BackColor = System.Drawing.Color.White;
            this.back.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.back.ForeColor = System.Drawing.SystemColors.Highlight;
            this.back.Location = new System.Drawing.Point(884, 440);
            this.back.Name = "back";
            this.back.Size = new System.Drawing.Size(100, 49);
            this.back.TabIndex = 16;
            this.back.Text = "Back>";
            this.back.UseVisualStyleBackColor = false;
            this.back.Click += new System.EventHandler(this.back_Click);
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("Algerian", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(512, 409);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(119, 68);
            this.button3.TabIndex = 18;
            this.button3.Text = "Sign Up";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // customer_Signup
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Studiofinal.Properties.Resources._286693_food_lunch_drink_hot_drink4;
            this.ClientSize = new System.Drawing.Size(1023, 520);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.back);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.checkBox1);
            this.Controls.Add(this.pbox);
            this.Controls.Add(this.ubox);
            this.Controls.Add(this.nbox);
            this.Controls.Add(this.ebox);
            this.Controls.Add(this.gender);
            this.Controls.Add(this.lbox);
            this.Controls.Add(this.fbox);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "customer_Signup";
            this.Text = "Customer signup ......";
            this.gender.ResumeLayout(false);
            this.gender.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider6)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox fbox;
        private System.Windows.Forms.TextBox lbox;
        private System.Windows.Forms.GroupBox gender;
        private System.Windows.Forms.RadioButton gButton3;
        private System.Windows.Forms.RadioButton gButton2;
        private System.Windows.Forms.RadioButton gButton1;
        private System.Windows.Forms.TextBox ebox;
        private System.Windows.Forms.TextBox nbox;
        private System.Windows.Forms.TextBox ubox;
        private System.Windows.Forms.TextBox pbox;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.ErrorProvider errorProvider2;
        private System.Windows.Forms.ErrorProvider errorProvider3;
        private System.Windows.Forms.ErrorProvider errorProvider4;
        private System.Windows.Forms.ErrorProvider errorProvider5;
        private System.Windows.Forms.ErrorProvider errorProvider6;
        private System.Windows.Forms.Button back;
        private System.Windows.Forms.Button button3;
    }
}