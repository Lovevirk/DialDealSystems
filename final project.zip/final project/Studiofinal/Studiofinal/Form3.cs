﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Studiofinal
{
    public partial class Merchant_Signup : Form
    {
        string Cname;
        string registrationN;
        string rePassword;
        string password;
        string Email;
        int phoneNumber;
        string companyAddress;
        public Merchant_Signup()
        {
            InitializeComponent();
            Pass.PasswordChar = '*'; // Hide password by default
            rePass.PasswordChar = '*'; // Hide password by default
        }

        private void number_TextChanged(object sender, EventArgs e)
        {
            if (!int.TryParse(number.Text, out int result))
            {
                // handle the case when the input is not a valid integer
                MessageBox.Show("Please enter a valid phone number.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                phoneNumber = 0; // set a default value
            }
            else
            {
                phoneNumber = int.Parse(number.Text);
            }
        }

        private void companyName_TextChanged(object sender, EventArgs e)
        {
            Cname = companyName.Text;
        }


        private void address_TextChanged(object sender, EventArgs e)
        {
            companyAddress = address.Text;
        }

        private void eMail_TextChanged(object sender, EventArgs e)
        {
            Email = eMail.Text;
        }

        private void rNumber_TextChanged(object sender, EventArgs e)
        {
            registrationN = rNumber.Text;
        }

        private void Pass_TextChanged(object sender, EventArgs e)
        {
            password = Pass.Text;
        }

        private void rePass_TextChanged(object sender, EventArgs e)
        {
            rePassword = rePass.Text;
        }

        private void disappear_CheckedChanged(object sender, EventArgs e)
        {
            if (disappear.Checked)
            {
                Pass.PasswordChar = '\0'; // Show password
                rePass.PasswordChar = '\0'; // Show password
            }
            else
            {
                Pass.PasswordChar = '*'; // Hide password
                rePass.PasswordChar = '*'; // Hide password
            }
        }

        private void back_Click(object sender, EventArgs e)
        {
            merchantorcustomer form = new merchantorcustomer();
            Hide();
            form.Show();

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(Cname) ||
             string.IsNullOrEmpty(companyAddress) ||
             string.IsNullOrEmpty(Email) ||
             string.IsNullOrEmpty(rePassword) ||
             string.IsNullOrWhiteSpace(rNumber.Text))
            {
                MessageBox.Show("Please fill in all the form details correctly.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (password != rePassword)
            {
                MessageBox.Show("Password do not match. Please re-enter passwords.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Pass.Text = "";
                rePass.Text = "";
            }
            if (string.IsNullOrEmpty(password) || password.Length < 8 || !password.Any(char.IsDigit) || !password.Any(char.IsLetter))
            {
                MessageBox.Show(" Password must contain at least one letter and one number, and be at least 8 characters long.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (!Email.Contains("@") || !Email.Contains(".com"))
            {
                MessageBox.Show(" Kindly Enter a valid Email.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                MessageBox.Show(" Welcome Merchant ");
                mAdddeals newdeal = new mAdddeals();

                Hide();
                newdeal.Show(); 
            }
        }
    }
}
