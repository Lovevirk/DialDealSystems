﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Studiofinal
{
    public partial class cart : Form
    {
        private List<Tuple<string, int>> cartItems;
      



        public cart(List<Tuple<string, int>> items)
        {
            InitializeComponent();
            cartItems = items;
            PopulateListView();
          
            
        }

        private void PopulateListView()
        {
            foreach (var item in cartItems)
            {
                string label = item.Item1;
                int quantity = item.Item2;

                string displayText = $"{label} * {quantity}"; // Display label and quantity

                ListViewItem listItem = new ListViewItem(displayText);
                listView1.Items.Add(listItem);
            }
        }
       



        public cart()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            payment paymentpage = new payment();
            Hide();
            paymentpage.Show(); 
        }

        private void back_Click(object sender, EventArgs e)
        {
           orderpage form = new orderpage();
           Hide();
           form.Show();
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void cart_Load(object sender, EventArgs e)
        {
            
        }
    }
}
