﻿namespace Studiofinal
{
    partial class Merchant_Signup
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.companyName = new System.Windows.Forms.TextBox();
            this.address = new System.Windows.Forms.TextBox();
            this.eMail = new System.Windows.Forms.TextBox();
            this.rNumber = new System.Windows.Forms.TextBox();
            this.number = new System.Windows.Forms.TextBox();
            this.Pass = new System.Windows.Forms.TextBox();
            this.rePass = new System.Windows.Forms.TextBox();
            this.disappear = new System.Windows.Forms.CheckBox();
            this.back = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // companyName
            // 
            this.companyName.Location = new System.Drawing.Point(80, 74);
            this.companyName.Name = "companyName";
            this.companyName.Size = new System.Drawing.Size(241, 22);
            this.companyName.TabIndex = 8;
            this.companyName.TextChanged += new System.EventHandler(this.companyName_TextChanged);
            // 
            // address
            // 
            this.address.Location = new System.Drawing.Point(80, 156);
            this.address.Multiline = true;
            this.address.Name = "address";
            this.address.Size = new System.Drawing.Size(241, 134);
            this.address.TabIndex = 9;
            this.address.TextChanged += new System.EventHandler(this.address_TextChanged);
            // 
            // eMail
            // 
            this.eMail.Location = new System.Drawing.Point(80, 352);
            this.eMail.Name = "eMail";
            this.eMail.Size = new System.Drawing.Size(241, 22);
            this.eMail.TabIndex = 10;
            this.eMail.TextChanged += new System.EventHandler(this.eMail_TextChanged);
            // 
            // rNumber
            // 
            this.rNumber.Location = new System.Drawing.Point(686, 74);
            this.rNumber.Name = "rNumber";
            this.rNumber.Size = new System.Drawing.Size(241, 22);
            this.rNumber.TabIndex = 11;
            this.rNumber.TextChanged += new System.EventHandler(this.rNumber_TextChanged);
            // 
            // number
            // 
            this.number.Location = new System.Drawing.Point(686, 166);
            this.number.Name = "number";
            this.number.Size = new System.Drawing.Size(241, 22);
            this.number.TabIndex = 12;
            this.number.TextChanged += new System.EventHandler(this.number_TextChanged);
            // 
            // Pass
            // 
            this.Pass.Location = new System.Drawing.Point(686, 257);
            this.Pass.Name = "Pass";
            this.Pass.Size = new System.Drawing.Size(241, 22);
            this.Pass.TabIndex = 13;
            this.Pass.TextChanged += new System.EventHandler(this.Pass_TextChanged);
            // 
            // rePass
            // 
            this.rePass.Location = new System.Drawing.Point(686, 352);
            this.rePass.Name = "rePass";
            this.rePass.Size = new System.Drawing.Size(241, 22);
            this.rePass.TabIndex = 14;
            this.rePass.TextChanged += new System.EventHandler(this.rePass_TextChanged);
            // 
            // disappear
            // 
            this.disappear.AutoSize = true;
            this.disappear.Location = new System.Drawing.Point(739, 380);
            this.disappear.Name = "disappear";
            this.disappear.Size = new System.Drawing.Size(72, 20);
            this.disappear.TabIndex = 15;
            this.disappear.Text = "Unhide";
            this.disappear.UseVisualStyleBackColor = true;
            this.disappear.CheckedChanged += new System.EventHandler(this.disappear_CheckedChanged);
            // 
            // back
            // 
            this.back.BackColor = System.Drawing.Color.White;
            this.back.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.back.ForeColor = System.Drawing.SystemColors.Highlight;
            this.back.Location = new System.Drawing.Point(881, 465);
            this.back.Name = "back";
            this.back.Size = new System.Drawing.Size(100, 49);
            this.back.TabIndex = 16;
            this.back.Text = "Back>";
            this.back.UseVisualStyleBackColor = false;
            this.back.Click += new System.EventHandler(this.back_Click);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Algerian", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(387, 425);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(119, 68);
            this.button1.TabIndex = 17;
            this.button1.Text = "Sign Up";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(60, 38);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(105, 16);
            this.label1.TabIndex = 18;
            this.label1.Text = "Company Name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(60, 121);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(58, 16);
            this.label2.TabIndex = 19;
            this.label2.Text = "Address";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(60, 312);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(45, 16);
            this.label3.TabIndex = 20;
            this.label3.Text = "E-Mail";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(656, 38);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(130, 16);
            this.label4.TabIndex = 21;
            this.label4.Text = "Registration Number";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(647, 121);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(97, 16);
            this.label7.TabIndex = 22;
            this.label7.Text = "Phone Number";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(656, 211);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(67, 16);
            this.label5.TabIndex = 23;
            this.label5.Text = "Password";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(656, 312);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(125, 16);
            this.label6.TabIndex = 24;
            this.label6.Text = "Re -enter Password";
            // 
            // Merchant_Signup
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Studiofinal.Properties.Resources._286693_food_lunch_drink_hot_drink3;
            this.ClientSize = new System.Drawing.Size(1017, 526);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.back);
            this.Controls.Add(this.disappear);
            this.Controls.Add(this.rePass);
            this.Controls.Add(this.Pass);
            this.Controls.Add(this.number);
            this.Controls.Add(this.rNumber);
            this.Controls.Add(this.eMail);
            this.Controls.Add(this.address);
            this.Controls.Add(this.companyName);
            this.Name = "Merchant_Signup";
            this.Text = "merchantSignUp";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox companyName;
        private System.Windows.Forms.TextBox address;
        private System.Windows.Forms.TextBox eMail;
        private System.Windows.Forms.TextBox rNumber;
        private System.Windows.Forms.TextBox number;
        private System.Windows.Forms.TextBox Pass;
        private System.Windows.Forms.TextBox rePass;
        private System.Windows.Forms.CheckBox disappear;
        private System.Windows.Forms.Button back;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
    }
}