﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Studiofinal
{
    public partial class rates : Form
    {
        public rates()
        {
            InitializeComponent();
        }

        private void back_Click(object sender, EventArgs e)
        {
           mAdddeals newdeals = new mAdddeals();
            Hide();
            newdeals.Show();
        }
    }
}
