﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Studiofinal
{
    public partial class Merchant_Login : Form
    {
        string username;
        string password;
        public Merchant_Login()
        {
            InitializeComponent();
        }
        private void Merchant_Login_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {
            username = textBox1.Text;
        }

        private void textBox2_TextChanged_1(object sender, EventArgs e)
        {
            password = textBox2.Text;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(username))
            {
                MessageBox.Show("Please fill all the information", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            if (string.IsNullOrEmpty(password) || password.Length < 8 || !password.Any(char.IsDigit) || !password.Any(char.IsLetter))
            {
                MessageBox.Show(" Password must contain at least one letter and one number, and be at least 8 characters long.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                MessageBox.Show(" SUCCEFULLY LOGIN AS MERCHANT ");

                mAdddeals newfrom = new mAdddeals();    
                Hide();
                newfrom.Show();
              

            }
        }

        private void back_Click(object sender, EventArgs e)
        {
            merchantorcustomer form = new merchantorcustomer();
            Hide();           
            form.Show();
        }
    }

}
    

