﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Studiofinal
{
    public partial class mAdddeals : Form
    {
        string deal;
        public mAdddeals()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(deal))
            {
                MessageBox.Show("Please fill a deal ", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                MessageBox.Show("Deal will be added after 10 mintues");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            merchantorcustomer newform = new merchantorcustomer();
            Hide();
            newform.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            rates newrates= new rates();
            Hide(); 
            newrates.Show();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            deal= textBox1.Text;

        }
    }
}
