﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Studiofinal
{

   
    public partial class orderpage : Form
    {
        private List<string> cartItems = new List<string>();

        public orderpage()
        {
            InitializeComponent();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            List<Tuple<string, int>> cartItems = new List<Tuple<string, int>>();
            if (!string.IsNullOrEmpty(label1.Text) && !string.IsNullOrEmpty(Quantity.Text))
            {
                int quantity;
                if (int.TryParse(Quantity.Text, out quantity) && quantity > 0)
                {
                    cartItems.Add(new Tuple<string, int>(label1.Text, quantity));
                }
            }
            if (!string.IsNullOrEmpty(label2.Text) && !string.IsNullOrEmpty(Quantity1.Text))
            {
                int quantity;
                if (int.TryParse(Quantity1.Text, out quantity) && quantity > 0)
                {
                    cartItems.Add(new Tuple<string, int>(label2.Text, quantity));
                }
            }
            if (!string.IsNullOrEmpty(label3.Text) && !string.IsNullOrEmpty(Quantity2.Text))
            {
                int quantity;
                if (int.TryParse(Quantity2.Text, out quantity) && quantity > 0)
                {
                    cartItems.Add(new Tuple<string, int>(label3.Text, quantity));
                }
            }

            if (cartItems.Count > 0)
            {
                cart cartpage = new cart(cartItems);
                cartpage.Show();
                Hide();
            }
            else
            {
                MessageBox.Show("No items with quantity greater than zero to add to the cart.");
            }
        }


        private void orderpage_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            merchantorcustomer newpage = new merchantorcustomer();
            Hide();
            newpage.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            ListView listView = new ListView();
            listView.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {

            int quantity;
            if (int.TryParse(Quantity.Text, out quantity))
            {
                quantity++;
                Quantity.Text = quantity.ToString();
                
                cartItems.Add(label1.Text);
            }
        }

        private void Quantity_TextChanged(object sender, EventArgs e)
        {

        }

        private void button7_Click(object sender, EventArgs e)
        {
            int quantity;
            if (int.TryParse(Quantity1.Text, out quantity))
            {
                quantity++;
                Quantity1.Text = quantity.ToString();
                cartItems.Add(label2.Text);
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            int quantity;
            if (int.TryParse(Quantity2.Text, out quantity))
            {
                quantity++;
                Quantity2.Text = quantity.ToString();
                cartItems.Add(label3.Text);
            }
        }

        private void button11_Click(object sender, EventArgs e)
        {
            int quantity;
            if (int.TryParse(Quantity2.Text, out quantity))
            {
                if (quantity > 0)  // Check if the quantity is greater than zero before decrementing
                {
                    quantity--;
                    Quantity2.Text = quantity.ToString();
                }
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            int quantity;
            if (int.TryParse(Quantity1.Text, out quantity))
            {
                if (quantity > 0)  // Check if the quantity is greater than zero before decrementing
                {
                    quantity--;
                    Quantity1.Text = quantity.ToString();
                }
            }
        }

        private void button10_Click(object sender, EventArgs e)
        {
            int quantity;
            if (int.TryParse(Quantity.Text, out quantity))
            {
                if (quantity > 0)  // Check if the quantity is greater than zero before decrementing
                {
                    quantity--;
                    Quantity.Text = quantity.ToString();
                }
            }
        }
    }
}
