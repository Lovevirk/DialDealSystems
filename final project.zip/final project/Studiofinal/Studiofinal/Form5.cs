﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Studiofinal
{
    public partial class customer_Signup : Form
    {
        string genders;
        public customer_Signup()
        {
            InitializeComponent();
        }

        private void fbox_Leave(object sender, EventArgs e)
        {
            if(string.IsNullOrEmpty(fbox.Text)==true)
            {
                fbox.Focus();
            }
            else
            {
                errorProvider1.Clear();
            }
        }

        private void lbox_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(lbox.Text) == true)
            {
                lbox.Focus();
            }
            else
            {
                errorProvider2.Clear();
            }
        }

        private void ebox_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(ebox.Text) == true)
            {
                ebox.Focus();
            }
            else
            {
                errorProvider3.Clear();
            }
        }

        private void nbox_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(nbox.Text) == true)
            {
                nbox.Focus();
            }
            else
            {
                errorProvider4.Clear();
            }
        }

        private void ubox_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(ubox.Text) == true)
            {
                ubox.Focus();
            }
            else
            {
                errorProvider5.Clear();
            }
        }

        private void pbox_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(pbox.Text) == true)
            {
                pbox.Focus();
            }
            else
            {
                errorProvider6.Clear();
            }
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if(checkBox1.Checked) 
            {
                pbox.UseSystemPasswordChar = false;
            }
            else
            {
                pbox.UseSystemPasswordChar= true;
            }
        }

      

        private void button2_Click(object sender, EventArgs e)
        {
            fbox.Clear();
            lbox.Clear();
            nbox.Clear();
            ebox.Clear();
            ubox.Clear();
            pbox.Clear();
            gender.ResetText();
        }

        private void back_Click(object sender, EventArgs e)
        {
            merchantorcustomer form = new merchantorcustomer();
            Hide();
            form.Show();
        }

        private void gButton1_CheckedChanged(object sender, EventArgs e)
        {
            genders = "Male";
            gender.Text = genders;
        }

        private void gButton2_CheckedChanged(object sender, EventArgs e)
        {
            genders = "Female";
            gender.Text = genders;
        }

        private void gButton3_CheckedChanged(object sender, EventArgs e)
        {
            genders = "Others";
            gender.Text = genders;
        }

        private void gender_Enter(object sender, EventArgs e)
        {
            if(!gButton1.Checked || !gButton2.Checked | !gButton3.Checked)
            {
                MessageBox.Show("Selection Essential");

            }
           
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(fbox.Text) == true)
            {
                fbox.Focus();
                errorProvider1.SetError(this.fbox, "pls fill firstname ");
            }
            else if (string.IsNullOrEmpty(lbox.Text) == true)
            {
                lbox.Focus();
                errorProvider2.SetError(this.lbox, "Please Fill Surname");
            }



            else if (string.IsNullOrEmpty(lbox.Text) == true)
            {
                lbox.Focus();
                errorProvider2.SetError(this.lbox, "Please Fill Surname");
            }
            else if (string.IsNullOrEmpty(ebox.Text) == true)
            {
                ebox.Focus();
                errorProvider3.SetError(this.ebox, "Please Fill your email");
            }
            else if (string.IsNullOrEmpty(nbox.Text) == true)
            {
                nbox.Focus();
                errorProvider4.SetError(this.nbox, "Please Fill your contact number");
            }



            else if (string.IsNullOrEmpty(ubox.Text) == true)
            {
                ubox.Focus();
                errorProvider5.SetError(this.ubox, "Please Fill your user name");
            }
            else if (string.IsNullOrEmpty(pbox.Text) == true)
            {
                pbox.Focus();
                errorProvider6.SetError(this.pbox, "Please Fill your password");
            }



            else
            {
                MessageBox.Show("Congratulations your account is created ");
                orderpage orderpageform = new orderpage();
                orderpageform.Show();
                Hide();    
            }
        }
    }
    
    
}
